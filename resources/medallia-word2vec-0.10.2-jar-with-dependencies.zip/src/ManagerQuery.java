import javafx.util.Pair;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.TreeMap;
import java.util.regex.Pattern;

public class ManagerQuery {
    private static Pattern topPat = Pattern.compile("<top>");
    boolean ifStem;
    boolean ifSemantic;
    TreeMap<String, String> dic;
    HashMap<String, String> dTable;
    ReadFile readFile;

    public ManagerQuery(boolean ifStem, boolean ifSemantic, TreeMap<String, String> dic, HashMap<String, String> dTable , ReadFile readFile) {
        this.ifStem=ifStem;
        this.ifSemantic=ifSemantic;
        this.dic=dic;
        this.dTable=dTable;
        this.readFile=readFile;
    }

    public LinkedList<String> startMakeAnswer(String query , String path ) throws IOException, ClassNotFoundException {
        Parse parser=new Parse(""  , new LinkedList<>() , false);
        query=query+" test test test";
        HashMap<String, Pair<Integer , Boolean>> queryAfterParse=parser.parseDoc("" , query , "");
        LinkedList<String> LinkOfQueryAfterParse=new LinkedList<>(queryAfterParse.keySet());
        Indexer indexer=new Indexer(path ,ifStem);
        indexer.reloadDictionary();
        indexer.reloadDocTable();
        TreeMap<String, String> dic=indexer.getTermDocFreqDic();
        HashMap<String,String> dTable=indexer.getDocTable();
        Searcher searcher=new Searcher(" " , path , dic , dTable , ifSemantic);
        LinkedList<String> afterRank=searcher.searchForRelevantDocs(LinkOfQueryAfterParse);
        System.out.println(afterRank.toString());
        return afterRank;
    }

    public String startMakeAnswerWithQueryFile(String pathForQuery ,String pathForPosting,Indexer indexer) throws IOException, ClassNotFoundException {
        File file2=new File(pathForPosting+"\\results.txt");
        file2.delete();
        file2=new File(pathForPosting+"\\answersToShow.txt");
        file2.delete();
        WriteFile writeFile=new WriteFile();
        StringBuilder stringBuilder=new StringBuilder();
        StringBuilder forQueryAnswer=new StringBuilder();


        String allText=readFile.readAllText(new File(pathForQuery)).toString();
        String[] afterSplit = topPat.split(allText);
        for (int i=1; i<afterSplit.length; i++) {
            System.out.println(i);
            forQueryAnswer = new StringBuilder();
            Query query = new Query(afterSplit[i]);
            Parse parser = new Parse("", readFile.stopWords, false);
            HashMap<String, Pair<Integer, Boolean>> queryAfterParse = parser.parseDoc("", query.getTitle() + " test test test", "");
            LinkedList<String> LinkOfQueryAfterParse = new LinkedList<>(queryAfterParse.keySet());
            Searcher searcher = new Searcher(pathForQuery, pathForPosting, dic, dTable, ifSemantic);
            LinkedList<String> afterSmallRank = searcher.searchForRelevantDocs(LinkOfQueryAfterParse);

            forQueryAnswer.append(query.getNum() + ": ");
            for (int x = 0; x < afterSmallRank.size(); x++) {
                forQueryAnswer.append(afterSmallRank.get(x) + ",");
            }
            forQueryAnswer.deleteCharAt(forQueryAnswer.length() - 1);
            forQueryAnswer.append("\n");
            writeFile.write(forQueryAnswer.toString(), pathForPosting + "\\answersToShow.txt");


            for (int j = 0; j < afterSmallRank.size(); j++) {
                writeFile.write(query.getNum() + " 0 " + afterSmallRank.get(j) + " 1 42.38 mt" + "\n", pathForPosting + "\\results.txt");
            }
        }


        //writeFile.write(stringBuilder.toString(),pathForPosting+"\\answers.txt");
        File file=new File(pathForPosting+"\\answersToShow.txt");
        Desktop.getDesktop().open(file);

        return stringBuilder.toString();
    }

}