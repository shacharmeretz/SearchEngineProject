import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.regex.Pattern;

public class viewController {

    @FXML
    public javafx.scene.control.CheckBox stemming;
    public javafx.scene.control.TextField pathToCorpus;
    public javafx.scene.control.TextField pathToDirectory;
    public javafx.scene.control.Button btn_delete;
    public javafx.scene.control.Button btn_searchPathToCorpus;
    public javafx.scene.control.Button btn_searchPathToPosting;
    public javafx.scene.control.Button btn_showTheDic;
    public javafx.scene.control.Button btn_toTheComputer;
    public javafx.scene.control.Button startMakeDictionary;
    public javafx.scene.control.Button btn_startMakeName;
    public javafx.scene.control.Button btn_startQuery;
    public javafx.scene.control.TextField query;
    public javafx.scene.control.Button btn_startQuerys;
    public javafx.scene.control.TextField pathToquery;
    public javafx.scene.control.CheckBox semantic;
    public javafx.scene.control.Button btn_searchPathToQueries;




    private static Pattern equalPat = Pattern.compile("=");
    private boolean ifStemming=false;
    private boolean ifSemantic=false;


    Indexer indexer;//=new Indexer(pathToDirectory.getText() , ifStemming );

    String pathWithStem;
    String pathWithNoStem = "C:\\Users\\shachar meretz\\Desktop\\try";
    public void startMakeDic() throws IOException, ClassNotFoundException {
        // C:\Users\meretz\IdeaProjects\peleg_shahar\Info_Retrieval\corpusForTest
        // C:\Users\meretz\IdeaProjects\peleg_shahar\Info_Retrieval\postingFile
        if (pathToCorpus.getText().isEmpty() || pathToDirectory.getText().isEmpty() || pathToCorpus == null || pathToDirectory == null) {
            showAlert("please enter the corpus and directory paths");
        } else {
            long startTime = System.nanoTime() / 1000000000;
            Path pathWithStemtemp = Paths.get(pathToDirectory.getText() + "\\stem");
            Files.createDirectories(pathWithStemtemp);
            pathWithStem = pathWithStemtemp.toString();
            Path pathWithNoStemtemp = Paths.get(pathToDirectory.getText() + "\\nostem");
            Files.createDirectories(pathWithNoStemtemp);
            pathWithNoStem = pathWithNoStemtemp.toString();

            if (ifStemming) {
                ReadFile x = new ReadFile(pathToCorpus.getText());
                x.readFromFile(ifStemming, pathWithStem.toString());
                indexer = new Indexer(pathWithStem.toString(), ifStemming);
                indexer.onIndexer();
            } else {
                ReadFile x = new ReadFile(pathToCorpus.getText());
                x.readFromFile(ifStemming, pathWithNoStem.toString());
                indexer = new Indexer(pathWithNoStem.toString(), ifStemming);
                indexer.onIndexer();
            }
            long endTime = System.nanoTime() / 1000000000;
            System.out.println("The total running time of the program is " + (endTime - startTime) + " seconds");
        }
    }

    public void startQuery() throws IOException, ClassNotFoundException {
        if (query.getText().isEmpty()){
            showAlert("please enter query");
        } else {
          //  ManagerQuery managerQuery=new ManagerQuery(ifStemming , ifSemantic);
           // managerQuery.startMakeAnswer(query.getText() , pathWithNoStem);
        }
    }

    public void startQuerys() throws IOException, ClassNotFoundException {
        if (pathToquery.getText().isEmpty()){
            showAlert("please enter the queries path");
        } else {
           // ManagerQuery managerQuery=new ManagerQuery(ifStemming , ifSemantic);
//            managerQuery.startMakeAnswerWithQueryFile(pathToquery.getText() , pathWithNoStem);
        }
    }
    public void ifStemming(Event event) {
        if(ifStemming==true)
            ifStemming=false;
        else
            ifStemming=true;
    }
    public void ifSemantic(Event event) {
        if(ifSemantic==true)
            ifSemantic=false;
        else
            ifSemantic=true;
    }

    public void deleteAll(Event event) {
        File directoryPathToCheck = new File( pathToDirectory.getText());
        File[] allTheFolderNameToCheck = directoryPathToCheck.listFiles();//all the folders in the folder
        if(allTheFolderNameToCheck.length==0)
        {
            showAlert("the folder is empty");
        }
        Path pathWithStemtemp = Paths.get(pathToDirectory.getText() + "\\stem");
        pathWithStem = pathWithStemtemp.toString();
        Path pathWithNoStemtemp = Paths.get(pathToDirectory.getText() + "\\nostem");
        pathWithNoStem = pathWithNoStemtemp.toString();


        File directoryPath = new File( pathWithStem);
        File[] allTheFolderName;
        allTheFolderName = directoryPath.listFiles();//all the folders in the folder
        for (int i = 0; i < allTheFolderName.length; i++) {
            allTheFolderName[i].delete();
        }
        directoryPath = new File(pathWithNoStem);
        allTheFolderName = directoryPath.listFiles();//all the folders in the folder
        for (int i = 0; i < allTheFolderName.length; i++) {
            allTheFolderName[i].delete();
        }
        File index = new File(pathWithNoStem);
        index.delete();
        File index2 = new File(pathWithStem);
        index2.delete();
    }


    public void browseQueries() {
        String path="";
        DirectoryChooser directoryChooser=new DirectoryChooser();
        Stage loadStage = new Stage();
        File file=directoryChooser.showDialog(loadStage);
        //  FileChooser fc = new FileChooser();
        //fc.setSelectedExtensionFilter(new FileChooser.ExtensionFilter("Maze files(.maze)", ".maze"));
        //  File fileToLoad = fc.showOpenDialog(loadStage);
        if (file != null) {
            path = file.getAbsolutePath();
            pathToquery.setText(path);
        }
    }

    public void browseCorpus() {
        String path="";
        DirectoryChooser directoryChooser=new DirectoryChooser();
        Stage loadStage = new Stage();
        File file=directoryChooser.showDialog(loadStage);
        //  FileChooser fc = new FileChooser();
        //fc.setSelectedExtensionFilter(new FileChooser.ExtensionFilter("Maze files(.maze)", ".maze"));
        //  File fileToLoad = fc.showOpenDialog(loadStage);
        if (file != null) {
            path = file.getAbsolutePath();
            pathToCorpus.setText(path);
        }
    }

    public void browsePostingFile() {
        String path="";
        DirectoryChooser directoryChooser=new DirectoryChooser();
        Stage loadStage = new Stage();
        File file=directoryChooser.showDialog(loadStage);
        //  FileChooser fc = new FileChooser();
        //fc.setSelectedExtensionFilter(new FileChooser.ExtensionFilter("Maze files(.maze)", ".maze"));
        //  File fileToLoad = fc.showOpenDialog(loadStage);
        if (file != null) {
            path = file.getAbsolutePath();
            pathToDirectory.setText(path);
        }
    }

    public void showTheDic(Event event) throws IOException, ClassNotFoundException {
        //Indexer indexer=new Indexer(pathToDirectory.getText() , ifStemming);
        if (ifStemming && (indexer == null && new File(pathWithStem + "\\DictionaryToDisplaystem.txt").exists()==false)) {
            showAlert("there is no dictionary to show\n Please click on load dictionary");
        }
        else if (ifStemming==false && indexer == null && new File(pathWithNoStem + "\\DictionaryToDisplaystem.txt").exists()==false) {
            showAlert("there is no dictionary to show\n Please click on load dictionary");
        }
        else {
            File file;
            if (ifStemming) {
                file = new File(pathWithStem + "\\DictionaryToDisplaystem.txt");
            } else {
                file = new File(pathWithNoStem + "\\DictionaryToDisplay.txt");
            }
            Desktop.getDesktop().open(file);
        }

        /*
        FXMLLoader fxmlLoader = new FXMLLoader();
        Parent root = fxmlLoader.load(getClass().getResource("/DictionaryDisplay.fxml").openStream());
        createNewScene(root);

         */
    }

    public void showEntity() throws IOException {
        File file;
        if (ifStemming) {
            file = new File(pathWithStem + "\\entity.txt");
        } else {
            file = new File(pathWithNoStem + "\\entity.txt");
        }
        Desktop.getDesktop().open(file);
    }

    public void loadTheDic() throws IOException, ClassNotFoundException {
        if (indexer==null){
            indexer=new Indexer(pathToDirectory.getText() , ifStemming );
        }
        indexer.reloadDictionary();
        indexer.reloadDocTable();
    }

    private void showAlert(String alertMessage) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setContentText(alertMessage);
        alert.show();
    }
}