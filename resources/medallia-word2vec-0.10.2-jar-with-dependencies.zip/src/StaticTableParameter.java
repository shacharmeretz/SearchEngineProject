import javafx.util.Pair;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.regex.Pattern;

public class StaticTableParameter implements Serializable {
    private static Pattern equalPat = Pattern.compile("=");
    private static Pattern parPat = Pattern.compile(":");
    String docNum;
    int countMaxWord; //how much the max word appear in the table
    int dictionarySize;//how many words in the table with counter
    int dictionaryWordCount;//how many diffrent words there are in the dictionary
    String fiveEntity;
    LinkedList<Pair<String,TermMetaData>> docEntities=new LinkedList<>();


    public StaticTableParameter(String docnum , int countMaxWord, int dictionarySize , int dictionaryWordCount)
    {
        this.docNum=docnum;
        this.countMaxWord=countMaxWord;
        this.dictionarySize=dictionarySize;
        this.dictionaryWordCount=dictionaryWordCount;
    }

    public StaticTableParameter(String allFields){
        String[] splited=equalPat.split(allFields);
        String[] entSplit;
        TermMetaData termMetaData;
        Pair<String,TermMetaData> pair;
        if(splited.length>=4){
            docNum=splited[0];
            countMaxWord=Integer.parseInt(splited[1]);
            dictionarySize=Integer.parseInt(splited[2]);
            dictionaryWordCount=Integer.parseInt(splited[3]);
            if(splited.length>4){
                for (int i=4;i<splited.length;i++){
                    entSplit=parPat.split(splited[i]);
                    termMetaData=new TermMetaData(Integer.parseInt(entSplit[1]),Boolean.valueOf(entSplit[2]));
                    pair=new Pair<>(entSplit[0],termMetaData);
                    docEntities.add(pair);
                }
            }
        }
    }


    public String toString()
    {
        StringBuilder stringBuilder=new StringBuilder();
        stringBuilder.append(docNum+"="+countMaxWord+"="+dictionarySize+"="+dictionaryWordCount);
        for (int i=0;i<docEntities.size();i++){
            stringBuilder.append("="+docEntities.get(i).getKey()+":"+docEntities.get(i).getValue().getFrequency()+":"+docEntities.get(i).getValue().isHeadLine());

        }
        return stringBuilder.toString();
    }


}