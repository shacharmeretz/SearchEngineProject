import com.medallia.word2vec.Word2VecModel;
import javafx.util.Pair;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.util.*;
import java.util.regex.Pattern;

public class Searcher {
    private HashMap<String , HashMap<String , Pair<Integer , Boolean>>> termsInfo;//term:docNo-5F,doNo-3T
    private HashMap<String,Integer> docsInfo;
    private int sizeOfCorpus;
    private ReadFile reader;

    private TreeMap<String, String> termDocFreqDic;// in file the value save at this format tf=lineNo
    private String pathForQuery;
    private HashMap<String,String> docTable;//value
    private String pathForPosting;
    private LinkedList<String> query;
    private static Pattern equalPat = Pattern.compile("=");
    private static Pattern patternPat = Pattern.compile(":");
    private boolean semantic;
    double avg;

    public Searcher(String pathForQuery , String pathForPosting,TreeMap<String, String> dic,HashMap<String,String> dTable , boolean semantic) throws IOException {
        this.pathForQuery=pathForQuery;
        reader=new ReadFile(pathForQuery);
        termDocFreqDic=dic;
        docTable=dTable;
        sizeOfCorpus=dTable.size();
        this.pathForPosting=pathForPosting;
        this.semantic=semantic;
        getAvg();
    }

    private void getAvg() throws IOException {
        ReadFile rf=new ReadFile(pathForPosting+"\\avg.txt");
        String str=rf.readAllText(new File(pathForPosting+"\\avg.txt")).toString();
        avg=Double.parseDouble(str);
    }


    public LinkedList<String> searchForRelevantDocs(LinkedList<String> query ) throws IOException {
        this.query=query;
        if(semantic==true)
        {
            LinkedList<String> semanticWords=semanticModelNoInternet();//addSemanticWordsToTheQuery();
            for (int i=0; i<semanticWords.size(); i++)
            {
                query.add(semanticWords.get(i));
            }
        }
        termsInfo=new HashMap<>();
        docsInfo=new HashMap<>();
        char firstLetter=' ';
        int lineNo;
        Set<String> set;
        String fileName="";
        for(int i=0;i<query.size();i++) {
            if (termDocFreqDic.containsKey(query.get(i))) {
                lineNo = Integer.parseInt(equalPat.split(termDocFreqDic.get(query.get(i)))[1]);
                firstLetter = query.get(i).charAt(0);
                fileName = findPostingFile(firstLetter);
                termsInfo.put(query.get(i), fromPostingFile(fileName, lineNo));
                set = termsInfo.get(query.get(i)).keySet();//all the docNo that contain query[i]
                for (String key : set
                ) {
                    if (!docsInfo.containsKey(key)) {
                        docsInfo.put(key, Integer.parseInt(equalPat.split(docTable.get(key))[2]));//docNo, doc length

                    }
                }
            }
        }
        return sendToRanker();
    }

    private String findPostingFile(char firstLetter){
        String fileName="";
        if (firstLetter>96 && firstLetter<123){
            fileName+=firstLetter;
        }
        else if(firstLetter>64 && firstLetter<91){
            fileName+=firstLetter;
            fileName=fileName.toLowerCase();
        }
        else if(firstLetter>47 && firstLetter<58){
            fileName="numbers";
        }
        return fileName;
    }

    private HashMap<String , Pair<Integer , Boolean>> fromPostingFile(String firstLetter, int lineNo) throws IOException {
        HashMap<String , Pair<Integer , Boolean>> infoFromPosting=new HashMap<>();
        String line=reader.readThisLine(pathForPosting+"\\"+firstLetter+".txt",lineNo);
        String[] lineSplited=patternPat.split(line);
        String[] secondSplit;
        Pair<Integer , Boolean> pair;
        for (int i=1; i<lineSplited.length;i++){
            secondSplit=equalPat.split(lineSplited[i]);
            pair=new Pair(Integer.parseInt(secondSplit[1]),Boolean.valueOf(secondSplit[2]));
            infoFromPosting.put(secondSplit[0],pair);
        }
        return infoFromPosting;
    }

    private LinkedList<String> sendToRanker() throws IOException {
        Ranker ranker=new Ranker(termsInfo,docsInfo,sizeOfCorpus , docTable , pathForPosting , avg);
        return ranker.calculateRank();
    }

    public LinkedList<String> semanticModelNoInternet() throws IOException{
        LinkedList<String> toRetrun=new LinkedList<>();
        try {
            for (int i = 0; i < query.size(); i++) {
                Word2VecModel model = Word2VecModel.fromTextFile(new File( "C:\\Users\\meretz\\IdeaProjects\\New folder\\Info_Retrieval\\word2vec.c.output.model.txt"));
                com.medallia.word2vec.Searcher searcher = model.forSearch();
                int num = 3;
                List<com.medallia.word2vec.Searcher.Match> matches = searcher.getMatches(query.get(i), num);
                for (com.medallia.word2vec.Searcher.Match match : matches) {
                    match.match();
                }
                for (int j = 1; j < matches.size(); j++) {
                    String temp=matches.get(j).toString();
                    String[] arr=temp.split("\\[");
                    arr[1]=arr[1].substring(0,arr[1].length()-1);
                    // if(Double.parseDouble(arr[1])>0.95)
                    toRetrun.add(arr[0]);
                }
            }
        }
        catch (com.medallia.word2vec.Searcher.UnknownWordException e)
        {

        }
        System.out.println(toRetrun.toString());
        return toRetrun;

    }

    private double getAvgDl() {
        double count=0;
        LinkedList<String> docNum=new LinkedList<>(docTable.keySet());
        for(int i=0; i<docNum.size() ; i++)
        {
            String str=equalPat.split(docTable.get(docNum.get(i)))[2];
            count+=Double.parseDouble(str);
        }
        return count/docNum.size();
    }

    //////////////////all this function for semantic with internet

    public LinkedList<String> addSemanticWordsToTheQuery()
    {
        LinkedList<String> whatWeAddToTheQueryList=new LinkedList<>();
        String path="https://api.datamuse.com/words?ml=";
        for(int i=0; i<query.size(); i++)
        {
            String wordOfQuery=query.get(i);
            if(wordOfQuery.contains(" "))
            {
                String[] split=wordOfQuery.split("\\s+");
                wordOfQuery=split[0];
                for (int j=1;j<split.length; j++)
                {
                    wordOfQuery="_"+split[i];
                }
            }
            String newPath=path+wordOfQuery;
            HashMap<String , Integer> allTheSemanticWords=useSemantic(newPath);
            LinkedList<String > afterRemoveScore=removeScore(allTheSemanticWords);
            for(int j=0; j<afterRemoveScore.size(); j++)
            {
                whatWeAddToTheQueryList.add(afterRemoveScore.get(j));
            }
        }
        return whatWeAddToTheQueryList;
    }
    private LinkedList<String> removeScore(HashMap<String, Integer> allTheSemanticWords) {
        LinkedList<String> toReturn=new LinkedList<>();
        LinkedList<String> keys=new LinkedList<>(allTheSemanticWords.keySet());
        for(int i=0; i<allTheSemanticWords.size(); i++)
        {
            if(allTheSemanticWords.get(keys.get(i))>75000)
            {
                toReturn.add(keys.get(i));
            }
            else {
                break;
            }
        }
        return toReturn;
    }

    public HashMap<String , Integer> useSemantic(String path) {
        HashMap<String, Integer> semanticWords = new HashMap<>();
        try {
            URL yahoo = new URL(path);
            URLConnection yc = yahoo.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
            String inputLine;
            String str = "";
            while ((inputLine = in.readLine()) != null) {
                str = inputLine;
            }
            in.close();
            String[] split = str.split("\\{");
            for (int i = 1; i < split.length; i++) {
                String[] split2 = split[i].split(":");
                String[] split3 = split2[1].split(",");
                String word = split3[0];
                word = word.substring(1, word.length() - 1);
                String[] split4 = split2[2].split(",");
                if(split4[0].charAt(split4[0].length()-1)<'0' || split4[0].charAt(split4[0].length()-1)>'9')
                    split4[0].substring(0,split4[0].length()-1);
                int score = Integer.parseInt(split4[0]);
                semanticWords.put(word, score);
                //System.out.println(word+" "+score);
            }
        }
        catch (IOException E)
        {
            System.out.println(path);
            System.out.println("problem with the URL");
        }
        catch (Exception e)
        {
            // System.out.println(e.toString());
        }
        //System.out.println(semanticWords.toString());
        return semanticWords;
    }
}